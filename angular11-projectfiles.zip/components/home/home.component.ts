import { Component, OnInit } from '@angular/core';
import { Post } from '../../models/post';
import { PostService } from '../../services/post.service';
import { UserService } from '../../services/user.service';
import { global } from '../../services/global';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
 
})
export class HomeComponent implements OnInit {

  public page_title: String;
  public url;
  public posts:Array<Post>;
  public identity;
  public token;


  constructor(
    
  ) {
    this.page_title = 'Bienvenido a Savia Latina';
    this.url = global.url;
    
  }
  ngOnInit(): void {
   
  } 
  
}
