import { Component, OnInit } from '@angular/core';
import {contactUser} from '../../models/user';
import {UserService} from '../../services/user.service';


@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css'],
  providers: [UserService]
})
export class ContactoComponent implements OnInit {
  
  public page_title:string;
  public user: contactUser;
  public status: string;
  constructor(
    private _userService: UserService
  ) { 
    this.page_title= "Contacto";
    this.user=new contactUser(1,'','','');
  }

  ngOnInit(): void {
    console.log(this._userService.test());
   }

  onSubmit(form ){
      
      console.log (this.user);
      this._userService.register(this.user).subscribe(
      response => {
        if (response.user && response.user._id){
          this.status = 'success';
          form.reset();
        }else{
          this.status= 'error'
        }

      }, 
      error =>{
        console.log(<any>error);
      }   

     );
      console.log(status);        
  }

}