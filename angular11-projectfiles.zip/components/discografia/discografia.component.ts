import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discografia',
  templateUrl: './discografia.component.html',
  styleUrls: ['./discografia.component.css']
})
export class DiscografiaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
