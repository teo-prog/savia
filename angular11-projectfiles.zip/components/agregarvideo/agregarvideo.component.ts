import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agregarvideo',
  templateUrl: './agregarvideo.component.html',
  styleUrls: ['./agregarvideo.component.css']
})
export class AgregarvideoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
