import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgregarvideoComponent } from './agregarvideo.component';

describe('AgregarvideoComponent', () => {
  let component: AgregarvideoComponent;
  let fixture: ComponentFixture<AgregarvideoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgregarvideoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgregarvideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
