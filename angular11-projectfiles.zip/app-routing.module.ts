// imports necesarios
import { NgModule } from '@angular/core';
import {  RouterModule, Routes } from '@angular/router';

//import components
import {LoginComponent}from'./components/login/login.component';
import {HomeComponent}from'./components/home/home.component';
import {AgregarvideoComponent} from './components/agregarvideo/agregarvideo.component'  ;
import { RedesComponent } from './components/redes/redes.component';
import { FotosComponent } from './components/fotos/fotos.component';
import { VideosComponent } from './components/videos/videos.component';
import { ContactoComponent } from './components/contacto/contacto.component';
import { RegisterComponent } from './components/register/register.component';
import { HistoryComponent } from './components/history/history.component';
import { BlogComponent } from './components/blog/blog.component';
import { DiscografiaComponent } from './components/discografia/discografia.component';
import { UserEditComponent} from './components/user-edit/user-edit.component';
import {CategoryNewComponent} from './components/category-new/category-new.component' ;
import {PostNewComponent}  from './components/post-new/post-new.component';
import{ PostDetailComponent} from './components/post-detail/post-detail.component';
import {PostEditComponent} from './components/post-edit/post-edit.component';
import{CategoryDetailComponent} from './components/category-detail/category-detail.component';
import {ProfileComponent} from './components/profile/profile.component';
//definir las rutas
import { IdentityGuard } from './services/identity.guard';

const routes: Routes=[
  {path:'',component: HomeComponent }, 
  {path:'inicio', component:HomeComponent},  
  {path:'login', component:LoginComponent },
  {path:'logout/:sure', component:LoginComponent },
  {path:'newvideo', component:AgregarvideoComponent},
  {path:'redes', component:RedesComponent},
  {path:'videos', component:VideosComponent},
  {path:'fotos', component:FotosComponent},
  {path:'crear-categoria', component: CategoryNewComponent, canActivate: [IdentityGuard] },
  {path:'contacto', component:ContactoComponent},
  {path:'register', component:RegisterComponent },
  {path:'historia', component:HistoryComponent },   
  {path:'entrada/:id', component:PostDetailComponent },
  {path:'blog', component:BlogComponent },
  {path:'discografia', component: DiscografiaComponent },
  {path:'ajustes', component: UserEditComponent, canActivate: [IdentityGuard] },
  {path:'crear-entrada', component: PostNewComponent, canActivate: [IdentityGuard] },
  {path:'editar-entrada/:id', component: PostEditComponent, canActivate: [IdentityGuard] },
  {path:'categoria/:id', component: CategoryDetailComponent },
  {path:'perfil/:id', component: ProfileComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
